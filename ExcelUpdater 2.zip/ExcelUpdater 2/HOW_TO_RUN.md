# Excel Updater — how to run

**No installation needed.** The one library this uses (openpyxl) is already
included in the `lib` folder next to the script. You do NOT need `pip`, and it
does not touch the internet or any proxy.

The only requirement is **Python 3**. Most machines have it. To check, open
Command Prompt (Windows) or Terminal (Mac) and type:

    python --version

If that prints something like `Python 3.11.4`, you're set. If it says the
command isn't found, try `python3 --version`. If neither works, ask IT to
install Python 3 — nothing else is required.

---

## Keep the folder together

Unzip anywhere. The folder must stay intact:

    ExcelUpdater\
        RUN_ME.bat             <- Windows: double-click this
        run_me.sh              <- Mac/Linux
        excel_updater.py
        template_config.json
        lib\                   <- the bundled library, do not delete
        HOW_TO_RUN.md

Copy your Excel file into this same folder.

---

## Easiest way (Windows)

1. Copy your `.xlsx` into the folder.
2. Double-click **RUN_ME.bat**.
3. It asks for the Excel file name.
4. It asks for the **unique id** (e.g. `BRP1E`). You are asked only once — the
   same id is used for both the preview and the output.
5. It shows a **preview** of every change and saves nothing.
6. If it looks right, type `Y` to write the output.

You get a new file named `UPDATED_YourFile.xlsx` in the same folder.
**Your original file is never modified.**

On Mac/Linux, run `./run_me.sh` instead.

---

## Command line (if you prefer)

Preview — saves nothing:

    python excel_updater.py --workbook MyWorkbook.xlsx --config template_config.json --dry-run

Write the output:

    python excel_updater.py --workbook MyWorkbook.xlsx --config template_config.json --output MyWorkbook_UPDATED.xlsx

Either way it asks:

    Enter the unique id (e.g. HAPPY):

Type the site id (e.g. `BRP1E`) and press Enter.

If you leave `--output` off, it edits your original file in place. Only do
that once you trust the results.

### Many files at once

Create `batch.csv`:

    workbook,uid
    siteA.xlsx,BRP1E
    siteB.xlsx,SND4A

Then:

    python excel_updater.py --batch batch.csv --config template_config.json

Batch mode takes ids from the CSV (no prompt) and edits each workbook
**in place**, so keep backups.

### Other flags

    --only append     only the row-adding steps
    --only update     only the NCX column overwrite
    --sheets "NCX"    limit to particular sheets

---

## What it does

| Sheet | Action |
|---|---|
| NCX-Sec-Obj-group-relationship | adds 6 rows after the last row (yellow) |
| NCX-Sec-Object_Group_PL | adds 6 rows after the last row (yellow) |
| NCX-Sec-ip-address-list | adds 8 rows (blue), then 15 rows (yellow) |
| NCX | finds the 4 subnet names in column I, overwrites O, U, V, AC, AD (yellow) |

Everything written is highlighted. Existing rows are never changed, except
the O/U/V/AC/AD cells in NCX where overwriting is intended.

### Column B in the yellow ip-address-list block

Rows where **column C is 17, 21, 40 or 38 are STATIC** — kept exactly as the
config says, never looked up.

Every other row (C = 24, 25, 43, 64, 28, ...) gets column B by searching
**upwards in the same sheet** for a row where **column C AND column D both
match exactly**, then copying that row's column B.

- Repeated C+D pairs are taken in sheet order: 1st match to the 1st new row,
  2nd to the 2nd, and so on.
- **If no matching C+D row exists, column B is left blank.**
- Source rows are only read, never modified.

---

## Messages you may see

- `WARNING: no row found for: sgi_direct_net_...` — those subnet names are not
  in that workbook. Informational, not a failure.
- `B left BLANK` — no row above had that exact C+D pair. The message names the
  pair it was looking for.
- `APPEND ABORTED: ... is not empty` — a safety stop. Nothing was written to
  that sheet. Send the message to whoever maintains this script.

---

## Changing the rules

`template_config.json` holds everything: which sheets, which rows, which
columns, and the static list. The static values live under

    append_sheets -> NCX-Sec-ip-address-list -> (second block) -> lookup -> skip_values

It is currently `[21, 17, 40, 38]`.
